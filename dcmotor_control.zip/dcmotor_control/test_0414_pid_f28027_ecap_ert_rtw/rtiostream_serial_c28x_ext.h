// Created on 28-Apr-2021 10:22:09
#ifndef RTIOSTREAM_SERIAL_C28X_EXT_H_
#define RTIOSTREAM_SERIAL_C28X_EXT_H_

#include "MW_target_hardware_resources.h"

// Baud Rate = 3750000
#define MW_PIL_SCIHBAUD 0
#define MW_PIL_SCILBAUD 1

#endif
