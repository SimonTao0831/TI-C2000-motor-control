/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: test_0414_pid_f28027_ecap.h
 *
 * Code generated for Simulink model 'test_0414_pid_f28027_ecap'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Wed Apr 28 10:21:50 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_test_0414_pid_f28027_ecap_h_
#define RTW_HEADER_test_0414_pid_f28027_ecap_h_
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef test_0414_pid_f28027_ecap_COMMON_INCLUDES_
# define test_0414_pid_f28027_ecap_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "dt_info.h"
#include "ext_work.h"
#include "c2000BoardSupport.h"
#include "F2802x_Device.h"
#include "f2802x_examples.h"
#include "IQmathLib.h"
#include "F2802x_Gpio.h"
#endif                          /* test_0414_pid_f28027_ecap_COMMON_INCLUDES_ */

#include "test_0414_pid_f28027_ecap_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

extern void init_CAP_GPIO();
extern void init_CAP1();
extern void config_ePWM_GPIO (void);

/* Block signals (default storage) */
typedef struct {
  real_T u;                            /* '<Root>/Saturation' */
  real_T u_n;                          /* '<Root>/Product' */
  real_T Sum;                          /* '<S42>/Sum' */
  uint32_T eCAP_o1;                    /* '<Root>/eCAP' */
  uint16_T u_a;                        /* '<Root>/eCAP' */
  uint16_T u_j;                        /* '<Root>/eCAP' */
  boolean_T NOT;                       /* '<Root>/NOT' */
} B_test_0414_pid_f28027_ecap_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T Integrator_DSTATE;            /* '<S33>/Integrator' */
  real_T Filter_DSTATE;                /* '<S28>/Filter' */
  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<Root>/Scope1' */

  struct {
    void *LoggedData;
  } Scope2_PWORK;                      /* '<Root>/Scope2' */

  struct {
    void *LoggedData;
  } _PWORK;                            /* '<Root>/�����ٶ�' */

  struct {
    void *LoggedData[2];
  } _PWORK_l;                          /* '<Root>/�۲�' */

  struct {
    void *LoggedData;
  } Scope3_PWORK;                      /* '<Root>/Scope3' */
} DW_test_0414_pid_f28027_ecap_T;

/* Parameters (default storage) */
struct P_test_0414_pid_f28027_ecap_T_ {
  real_T PIDController_InitialConditionF;
                              /* Mask Parameter: PIDController_InitialConditionF
                               * Referenced by: '<S28>/Filter'
                               */
  real_T PIDController_InitialConditio_g;
                              /* Mask Parameter: PIDController_InitialConditio_g
                               * Referenced by: '<S33>/Integrator'
                               */
  real_T Constant_Value;               /* Expression: 2*60*10^6*60
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 6000
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Constant1_Value;              /* Expression: 3843.6865234375
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T Constant4_Value;              /* Expression: 3.6
                                        * Referenced by: '<Root>/Constant4'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S33>/Integrator'
                                        */
  real_T Constant6_Value;              /* Expression: 0.1
                                        * Referenced by: '<Root>/Constant6'
                                        */
  real_T Filter_gainval;               /* Computed Parameter: Filter_gainval
                                        * Referenced by: '<S28>/Filter'
                                        */
  real_T Constant7_Value;              /* Expression: 100
                                        * Referenced by: '<Root>/Constant7'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 15000
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: 0
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  real_T Constant3_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant3'
                                        */
  real_T Constant5_Value;              /* Expression: 30
                                        * Referenced by: '<Root>/Constant5'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_test_0414_pid_f28027__T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_test_0414_pid_f28027_ecap_T test_0414_pid_f28027_ecap_P;

/* Block signals (default storage) */
extern B_test_0414_pid_f28027_ecap_T test_0414_pid_f28027_ecap_B;

/* Block states (default storage) */
extern DW_test_0414_pid_f28027_ecap_T test_0414_pid_f28027_ecap_DW;

/* Model entry point functions */
extern void test_0414_pid_f28027_ecap_initialize(void);
extern void test_0414_pid_f28027_ecap_step(void);
extern void test_0414_pid_f28027_ecap_terminate(void);

/* Real-time Model object */
extern RT_MODEL_test_0414_pid_f28027_T *const test_0414_pid_f28027_ecap_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'test_0414_pid_f28027_ecap'
 * '<S1>'   : 'test_0414_pid_f28027_ecap/PID Controller'
 * '<S2>'   : 'test_0414_pid_f28027_ecap/PID Controller/Anti-windup'
 * '<S3>'   : 'test_0414_pid_f28027_ecap/PID Controller/D Gain'
 * '<S4>'   : 'test_0414_pid_f28027_ecap/PID Controller/Filter'
 * '<S5>'   : 'test_0414_pid_f28027_ecap/PID Controller/Filter ICs'
 * '<S6>'   : 'test_0414_pid_f28027_ecap/PID Controller/I Gain'
 * '<S7>'   : 'test_0414_pid_f28027_ecap/PID Controller/Ideal P Gain'
 * '<S8>'   : 'test_0414_pid_f28027_ecap/PID Controller/Ideal P Gain Fdbk'
 * '<S9>'   : 'test_0414_pid_f28027_ecap/PID Controller/Integrator'
 * '<S10>'  : 'test_0414_pid_f28027_ecap/PID Controller/Integrator ICs'
 * '<S11>'  : 'test_0414_pid_f28027_ecap/PID Controller/N Copy'
 * '<S12>'  : 'test_0414_pid_f28027_ecap/PID Controller/N Gain'
 * '<S13>'  : 'test_0414_pid_f28027_ecap/PID Controller/P Copy'
 * '<S14>'  : 'test_0414_pid_f28027_ecap/PID Controller/Parallel P Gain'
 * '<S15>'  : 'test_0414_pid_f28027_ecap/PID Controller/Reset Signal'
 * '<S16>'  : 'test_0414_pid_f28027_ecap/PID Controller/Saturation'
 * '<S17>'  : 'test_0414_pid_f28027_ecap/PID Controller/Saturation Fdbk'
 * '<S18>'  : 'test_0414_pid_f28027_ecap/PID Controller/Sum'
 * '<S19>'  : 'test_0414_pid_f28027_ecap/PID Controller/Sum Fdbk'
 * '<S20>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tracking Mode'
 * '<S21>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tracking Mode Sum'
 * '<S22>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tsamp - Integral'
 * '<S23>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tsamp - Ngain'
 * '<S24>'  : 'test_0414_pid_f28027_ecap/PID Controller/postSat Signal'
 * '<S25>'  : 'test_0414_pid_f28027_ecap/PID Controller/preSat Signal'
 * '<S26>'  : 'test_0414_pid_f28027_ecap/PID Controller/Anti-windup/Passthrough'
 * '<S27>'  : 'test_0414_pid_f28027_ecap/PID Controller/D Gain/External Parameters'
 * '<S28>'  : 'test_0414_pid_f28027_ecap/PID Controller/Filter/Disc. Forward Euler Filter'
 * '<S29>'  : 'test_0414_pid_f28027_ecap/PID Controller/Filter ICs/Internal IC - Filter'
 * '<S30>'  : 'test_0414_pid_f28027_ecap/PID Controller/I Gain/External Parameters'
 * '<S31>'  : 'test_0414_pid_f28027_ecap/PID Controller/Ideal P Gain/Passthrough'
 * '<S32>'  : 'test_0414_pid_f28027_ecap/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S33>'  : 'test_0414_pid_f28027_ecap/PID Controller/Integrator/Discrete'
 * '<S34>'  : 'test_0414_pid_f28027_ecap/PID Controller/Integrator ICs/Internal IC'
 * '<S35>'  : 'test_0414_pid_f28027_ecap/PID Controller/N Copy/Disabled'
 * '<S36>'  : 'test_0414_pid_f28027_ecap/PID Controller/N Gain/External Parameters'
 * '<S37>'  : 'test_0414_pid_f28027_ecap/PID Controller/P Copy/Disabled'
 * '<S38>'  : 'test_0414_pid_f28027_ecap/PID Controller/Parallel P Gain/External Parameters'
 * '<S39>'  : 'test_0414_pid_f28027_ecap/PID Controller/Reset Signal/Disabled'
 * '<S40>'  : 'test_0414_pid_f28027_ecap/PID Controller/Saturation/Passthrough'
 * '<S41>'  : 'test_0414_pid_f28027_ecap/PID Controller/Saturation Fdbk/Disabled'
 * '<S42>'  : 'test_0414_pid_f28027_ecap/PID Controller/Sum/Sum_PID'
 * '<S43>'  : 'test_0414_pid_f28027_ecap/PID Controller/Sum Fdbk/Disabled'
 * '<S44>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tracking Mode/Disabled'
 * '<S45>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S46>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tsamp - Integral/Passthrough'
 * '<S47>'  : 'test_0414_pid_f28027_ecap/PID Controller/Tsamp - Ngain/Passthrough'
 * '<S48>'  : 'test_0414_pid_f28027_ecap/PID Controller/postSat Signal/Forward_Path'
 * '<S49>'  : 'test_0414_pid_f28027_ecap/PID Controller/preSat Signal/Forward_Path'
 */
#endif                             /* RTW_HEADER_test_0414_pid_f28027_ecap_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
