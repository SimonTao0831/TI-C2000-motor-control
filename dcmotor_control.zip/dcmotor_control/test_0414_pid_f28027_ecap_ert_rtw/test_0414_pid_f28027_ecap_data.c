/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: test_0414_pid_f28027_ecap_data.c
 *
 * Code generated for Simulink model 'test_0414_pid_f28027_ecap'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Wed Apr 28 10:21:50 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "test_0414_pid_f28027_ecap.h"
#include "test_0414_pid_f28027_ecap_private.h"

/* Block parameters (default storage) */
P_test_0414_pid_f28027_ecap_T test_0414_pid_f28027_ecap_P = {
  /* Mask Parameter: PIDController_InitialConditionF
   * Referenced by: '<S28>/Filter'
   */
  0.0,

  /* Mask Parameter: PIDController_InitialConditio_g
   * Referenced by: '<S33>/Integrator'
   */
  0.0,

  /* Expression: 2*60*10^6*60
   * Referenced by: '<Root>/Constant'
   */
  7.2E+9,

  /* Expression: 6000
   * Referenced by: '<Root>/Saturation'
   */
  6000.0,

  /* Expression: 0
   * Referenced by: '<Root>/Saturation'
   */
  0.0,

  /* Expression: 3843.6865234375
   * Referenced by: '<Root>/Constant1'
   */
  3843.6865234375,

  /* Expression: 1
   * Referenced by: '<Root>/Constant2'
   */
  1.0,

  /* Expression: 3.6
   * Referenced by: '<Root>/Constant4'
   */
  3.6,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S33>/Integrator'
   */
  0.01,

  /* Expression: 0.1
   * Referenced by: '<Root>/Constant6'
   */
  0.1,

  /* Computed Parameter: Filter_gainval
   * Referenced by: '<S28>/Filter'
   */
  0.01,

  /* Expression: 100
   * Referenced by: '<Root>/Constant7'
   */
  100.0,

  /* Expression: 15000
   * Referenced by: '<Root>/Saturation1'
   */
  15000.0,

  /* Expression: 0
   * Referenced by: '<Root>/Saturation1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Constant3'
   */
  1.0,

  /* Expression: 30
   * Referenced by: '<Root>/Constant5'
   */
  30.0
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
