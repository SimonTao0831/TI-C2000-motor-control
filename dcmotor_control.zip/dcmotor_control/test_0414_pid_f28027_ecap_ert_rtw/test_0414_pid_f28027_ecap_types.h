/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: test_0414_pid_f28027_ecap_types.h
 *
 * Code generated for Simulink model 'test_0414_pid_f28027_ecap'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Wed Apr 28 10:21:50 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_test_0414_pid_f28027_ecap_types_h_
#define RTW_HEADER_test_0414_pid_f28027_ecap_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_test_0414_pid_f28027_ecap_T_ P_test_0414_pid_f28027_ecap_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_test_0414_pid_f28027__T RT_MODEL_test_0414_pid_f28027_T;

#endif                       /* RTW_HEADER_test_0414_pid_f28027_ecap_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
